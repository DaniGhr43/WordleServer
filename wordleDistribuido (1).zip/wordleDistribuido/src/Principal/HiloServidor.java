package Principal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class HiloServidor extends Thread{

	BufferedReader fentrada;
	PrintWriter fsalida;
	Socket socket;
	
	public HiloServidor(Socket s) {
		
		this.socket=s;
		try {
			fsalida=new PrintWriter(socket.getOutputStream(), true);
			fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error en E/S");
			e.printStackTrace();
		}
				
	}
	
	
	public void run() {
		//String para cada cliente que se conecte
		
		String []palabras= {"PLATO","PISAR","PLANO","MAREO","LISTA","LISTO",
				"SUCIO","PERRO","MIXTO","BULTO","CASTO","PRADO","MOSCA","PISTO",
				"TURCO","BRAVO","VISTO","QUESO","GUISO","USADO"};		
		String cadenaUsuario="";
		String adivina="";
		//Genero un número aleatorio entre 0 y 20 para seleccionar la palabra
		int posicion=(int)(Math.random()*20);
				
		fsalida.println(palabras[posicion]);
		
		try {
			do {				
				cadenaUsuario=fentrada.readLine();
				if(!cadenaUsuario.equals("*")) {
					adivina=comparar(palabras[posicion],cadenaUsuario);
					fsalida.println(adivina);		
				}					
			}while(!cadenaUsuario.equals("*"));
													
			fsalida.close();
			fentrada.close();
			socket.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String comparar(String secreta, String usuario) {
		// TODO Auto-generated method stub
		String adivina="";
		//Comprueba si ha adivinado la posición de alguna letra
		for(int i=0; i<secreta.length(); i++) {
			if(secreta.charAt(i)==usuario.charAt(i)) {
				adivina=adivina+secreta.charAt(i);
			}else {
				adivina=adivina+" _ ";
			}
		}
		
		return adivina;
		
	}

}
