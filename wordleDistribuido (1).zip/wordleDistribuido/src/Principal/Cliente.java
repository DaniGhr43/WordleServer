package Principal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

	
	
	public static void main(String[] args) {
		String host ="localhost";
		int puerto = 6000;
		Scanner sc= new Scanner(System.in);
		
		try {
			
			Socket cliente = new Socket (host, puerto);
			PrintWriter fsalida = new PrintWriter(cliente.getOutputStream(), true);
			BufferedReader fentrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
			String cadena = "";
			int intentos=6;
			String palabraCorrecta=fentrada.readLine();
			System.out.println(palabraCorrecta);
			do {
			
				do {
					System.out.println("Dame una palabra de 5 letras");
					cadena = sc.next();
					
				}while(!cadena.matches("^[A-Z]{5}$"));

				
				fsalida.println(cadena);
				
				cadena=fentrada.readLine();
				System.out.println(cadena);
				intentos--;
				
			}while(intentos>0 && !cadena.equals(palabraCorrecta));
			
		
			fsalida.println("*");
			
			
			if(palabraCorrecta.equals(cadena))
				System.out.println("Espléndido!!");
			else
				System.out.println("Fallaste. La palabra era: "+palabraCorrecta);
			
		
			cliente.close();
			sc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	
	
	
}
